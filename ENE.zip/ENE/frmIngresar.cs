﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistema_req_part1
{
    public partial class frmIngresar : Form
    {
        public frmIngresar()
        {
            InitializeComponent();
        }

        private void frmIngresar_Load(object sender, EventArgs e)
        {


            //
            cmbTipo_Requerimiento.DisplayMember = "Text";
            cmbTipo_Requerimiento.ValueMember = "Value";
            var itemsReq = new[] {
                new {Text ="Seleccionar",Value = "0" },
                new {Text ="Base de Datos",Value = "1" },
                new {Text ="Sistemas",Value = "3" },
                new {Text ="Instalacion de Software",Value = "5" },
            };
            cmbTipo_Requerimiento.DataSource = itemsReq;
            //
            cmbAsignacion.DisplayMember = "Text";
            cmbAsignacion.ValueMember = "Value";
            var itemsUsuario = new[]
            {
            new {Text ="Seleccionar",Value = "0" },
            new {Text = "Mardoche Charitable" , Value = "Mardoccha"},
            new {Text = "Carolina Vergara" , Value = "Kro.damian"},
            };
            cmbAsignacion.DataSource = itemsUsuario;
            //
            cmbPrioridad.DisplayMember = "Text";
            cmbPrioridad.ValueMember = "Value";
            var itemsPrioridad = new[]
            {
            new {Text ="Seleccionar",Value = "0" },
            new {Text = "Alta" , Value = "2"},
            new {Text = "Media" , Value = "4"},
            new {Text = "Baja" , Value = "6"},
            };

            cmbPrioridad.DataSource = itemsPrioridad;


            // dejar todo slos combobox sin ninguna seleccion
            cmbTipo_Requerimiento.SelectedIndex = -1;
            cmbAsignacion.SelectedIndex = -1;
            cmbPrioridad.SelectedIndex = -1;
        }

        private void btnGuardar_Click(object sender, EventArgs e)
        {

            // Validar
            if (cmbAsignacion.SelectedIndex == -1)
            {
                MessageBox.Show("Estimado usuario, debe seleccionar el usuario responsable antes de Grabar");
                return;
            }

            if (txtdescripcion.TextLength == 0)
            {
                MessageBox.Show("Estimado usuario, debe ingresar la descripcion del requerimientos antes de Grabar");
                return;
            }

            if (cmbTipo_Requerimiento.SelectedIndex == -1)
            {
                MessageBox.Show("Estimado usuario, debe seleccionar el tipo de requerimientos antes de Grabar");
                return;
            }

            if (cmbPrioridad.SelectedIndex == -1)
            {
                MessageBox.Show("Estimado usuario, debe seleccionar el tipo prioridad antes de Grabar");
                return;
            }

            // Crear el objeto REQ de tipo Requerimiento
            Requerimiento req = new Requerimiento();


            // capturar la infomracion ingresada por el usuario
            // y la ssigaremso al objet REQ
            req.Descripcion = txtdescripcion.Text;
            req.Id_user = cmbAsignacion.SelectedValue.ToString();
            req.Cod_tipo = Convert.ToInt32(cmbTipo_Requerimiento.SelectedValue);
            req.Cod_prioridad = Convert.ToInt32(cmbPrioridad.SelectedValue);

            string MensajeRetorno;
            MensajeRetorno = req.Grabar();

            MessageBox.Show(MensajeRetorno);

        }

        private void btnLista_Req_Click(object sender, EventArgs e)
        {
            frmConsultar fConsulta = new frmConsultar();
            fConsulta.MdiParent = this.ParentForm; // asignando un valor en tiempo/modo de ejecucion
            fConsulta.Show();

        }

        private void btnLimpiarCampo_Click(object sender, EventArgs e)
        {
            txtdescripcion.Text = "";
            cmbTipo_Requerimiento.SelectedIndex = -1;
            cmbPrioridad.SelectedIndex = -1;
            cmbAsignacion.SelectedIndex = -1;
        }

        private void cmbAsignacion_SelectedIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
