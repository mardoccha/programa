-- =============================================
-- Author:		MC
-- Create date: 15-12-2020
-- Description:	Validar Usuario
--permita validar el usuario y su clave para acceder al sistema
-- =============================================
CREATE PROCEDURE sp_VALIDAR_USUARIO
	-- aqui los parametros de entradas y de salidas
	@Id_User VARCHAR(30),
    @Clave VARCHAR(20)


AS
BEGIN
--validar la pk
     IF NOT EXISTS (SELECT Id_User FROM USUARIO
              WHERE Id_User =@Id_User  )
       BEGIN   --Usuario no existe en el sistema
	         SELECT 1 AS Codigo_Ret, 'Usuario Incorrecto' AS Mensaje_Ret;
			 return
		END
	   ELSE  IF NOT EXISTS(SELECT Id_User FROM USUARIO
              WHERE Id_User =@Id_User  AND Clave= @Clave)
	   BEGIN
	  SELECT -1 AS  Codigo_Ret, 'Clave Incorrecta' AS Mensaje_Ret;
	   END
	   ELSE
	   SELECT 0 AS  Codigo_Ret, 'Usuario Autorizado' AS Mensaje_Ret;
	   END

	   --Prueba sp_ELIMINAR_CLIENTE
--codigo 0
EXEC sp_VALIDAR_USUARIO 'Mardoccha','15121989'
--codigo 1
EXEC sp_VALIDAR_USUARIO 'Mardocha','15121989'
--codigo -1
EXEC sp_VALIDAR_USUARIO 'Mardoccha','12121989'
