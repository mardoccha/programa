-- =============================================
-- Author:		MC
-- Create date: 15-12-2020
-- Description:	Agregar nuevo un requerimiento
-- ======================================


CREATE PROCEDURE SP_Grabrar_Req(  
					   @Descripcion VARCHAR(200),
					   @Cod_tipo INT,
					   @Cod_prioridad INT,
					   @Id_user VARCHAR(30))
						
as begin
 declare
		 @plazo varchar(10)
		
 select @plazo  = plazo  from PRIORIDAD where Cod_prioridad = @Cod_prioridad
 insert REQUERIMIENTO select 'P',@Descripcion, getdate(), @Cod_tipo ,@Cod_prioridad, @Id_user
   select 0 as Codigo_Ret,'Requerimiento ' + ' fue grabado, el plazo para resolverlo es ' + @plazo  as Mensaje_Ret
   
end

select * from TIPO_REQUERIMIENTO
select * from PRIORIDAD
select * from USUARIO