﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistema_req_part1
{
    class Requerimiento
    {

        // Metodo Constructor de la clase Requerimiento
        public Requerimiento()
        {
            
            Descripcion = "nuevo requerimiento.";
            Estado = "P";
            Cod_tipo = 1;
            Cod_prioridad = 2;
            Fecha = DateTime.Now; // Getdate de SQL
            Id_user = "";
        }

        
        public string Descripcion { get; set; }
        public string Estado { get; set; }
        public int Cod_tipo { get; set; }
        public int Cod_prioridad { get; set; }
        public DateTime Fecha { get; set; }
        public string Id_user { get; set; }


        public string Grabar()
        {
            // establecer la conexion
            string cadenaConexion = "Server = DESKTOP-Q3S0R8O\\SQLEXPRESS ; Database = ENE_AIEP;  integrated security = true";
            SqlConnection sqlCon = new SqlConnection(cadenaConexion);
            sqlCon.Open();

            // ejecutar llamada al sp que esta en la base de datos
            SqlCommand sqlCmd;

            // exec ValidarUsuario 'blisboa','123456'
            sqlCmd = new SqlCommand("SP_Grabrar_Req", sqlCon);
            sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlCmd.Parameters.AddWithValue("@Cod_tipo", Cod_tipo);
            sqlCmd.Parameters.AddWithValue("@Id_user", Id_user);
            sqlCmd.Parameters.AddWithValue("@Descripcion", Descripcion);
            sqlCmd.Parameters.AddWithValue("@Cod_prioridad", Cod_prioridad);

            SqlDataAdapter sqlSda = new SqlDataAdapter(sqlCmd);
            DataTable dtData = new DataTable();
            sqlSda.Fill(dtData);

            // Validar si el usuario tiene o no tiene al Sistema
            if (dtData.Rows.Count > 0)
            {
                return dtData.Rows[0]["Mensaje_Ret"].ToString();
            }
            else
            {
                return "No fue posible grabar el requerimiento.";
            }

            sqlCon.Close();
        }

    }
}