CREATE TABLE MENU( Cod_menu VARCHAR(10) NOT NULL,
                     Menu VARCHAR(50) NOT NULL,
					 URL VARCHAR(100) NOT NULL,
					 
                     CONSTRAINT pk_Menu PRIMARY KEY(Cod_menu)
					 );



SELECT *FROM MENU;


INSERT INTO MENU(Cod_menu, Menu, URL) 
VALUES ('SRO1', 'Ingresar Requerimiento', 'http://misitio/IR.ENE'),
       ('SRO2', 'Consular Requerimiento', 'http://misitio/CR.ENE');