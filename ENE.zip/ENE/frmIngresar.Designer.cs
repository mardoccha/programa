﻿
namespace sistema_req_part1
{
    partial class frmIngresar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbTipo_Requerimiento = new System.Windows.Forms.ComboBox();
            this.cmbAsignacion = new System.Windows.Forms.ComboBox();
            this.cmbPrioridad = new System.Windows.Forms.ComboBox();
            this.btnGuardar = new System.Windows.Forms.Button();
            this.btnLimpiarCampo = new System.Windows.Forms.Button();
            this.btnLista_Req = new System.Windows.Forms.Button();
            this.lbRequerimiento = new System.Windows.Forms.Label();
            this.lbTipo_Requerimiento = new System.Windows.Forms.Label();
            this.lbAsignado = new System.Windows.Forms.Label();
            this.lbOpcion = new System.Windows.Forms.Label();
            this.lbDescripcion = new System.Windows.Forms.Label();
            this.lbAsignacion = new System.Windows.Forms.Label();
            this.txtdescripcion = new System.Windows.Forms.TextBox();
            this.lbPrioridad = new System.Windows.Forms.Label();
            this.lbOpPrioridad = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // cmbTipo_Requerimiento
            // 
            this.cmbTipo_Requerimiento.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.cmbTipo_Requerimiento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbTipo_Requerimiento.FormattingEnabled = true;
            this.cmbTipo_Requerimiento.Location = new System.Drawing.Point(273, 48);
            this.cmbTipo_Requerimiento.Name = "cmbTipo_Requerimiento";
            this.cmbTipo_Requerimiento.Size = new System.Drawing.Size(231, 21);
            this.cmbTipo_Requerimiento.TabIndex = 0;
            // 
            // cmbAsignacion
            // 
            this.cmbAsignacion.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.cmbAsignacion.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbAsignacion.FormattingEnabled = true;
            this.cmbAsignacion.Location = new System.Drawing.Point(273, 113);
            this.cmbAsignacion.Name = "cmbAsignacion";
            this.cmbAsignacion.Size = new System.Drawing.Size(231, 21);
            this.cmbAsignacion.TabIndex = 1;
            this.cmbAsignacion.SelectedIndexChanged += new System.EventHandler(this.cmbAsignacion_SelectedIndexChanged);
            // 
            // cmbPrioridad
            // 
            this.cmbPrioridad.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.cmbPrioridad.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPrioridad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cmbPrioridad.FormattingEnabled = true;
            this.cmbPrioridad.Location = new System.Drawing.Point(273, 347);
            this.cmbPrioridad.Name = "cmbPrioridad";
            this.cmbPrioridad.Size = new System.Drawing.Size(231, 24);
            this.cmbPrioridad.TabIndex = 2;
            // 
            // btnGuardar
            // 
            this.btnGuardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnGuardar.Location = new System.Drawing.Point(132, 438);
            this.btnGuardar.Name = "btnGuardar";
            this.btnGuardar.Size = new System.Drawing.Size(114, 36);
            this.btnGuardar.TabIndex = 3;
            this.btnGuardar.Text = "Guardar";
            this.btnGuardar.UseVisualStyleBackColor = true;
            this.btnGuardar.Click += new System.EventHandler(this.btnGuardar_Click);
            // 
            // btnLimpiarCampo
            // 
            this.btnLimpiarCampo.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLimpiarCampo.Location = new System.Drawing.Point(288, 438);
            this.btnLimpiarCampo.Name = "btnLimpiarCampo";
            this.btnLimpiarCampo.Size = new System.Drawing.Size(137, 36);
            this.btnLimpiarCampo.TabIndex = 4;
            this.btnLimpiarCampo.Text = "Limpiar Campos";
            this.btnLimpiarCampo.UseVisualStyleBackColor = true;
            this.btnLimpiarCampo.Click += new System.EventHandler(this.btnLimpiarCampo_Click);
            // 
            // btnLista_Req
            // 
            this.btnLista_Req.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnLista_Req.Location = new System.Drawing.Point(461, 438);
            this.btnLista_Req.Name = "btnLista_Req";
            this.btnLista_Req.Size = new System.Drawing.Size(204, 35);
            this.btnLista_Req.TabIndex = 5;
            this.btnLista_Req.Text = "Ir a Lista Requerimiento";
            this.btnLista_Req.UseVisualStyleBackColor = true;
            this.btnLista_Req.Click += new System.EventHandler(this.btnLista_Req_Click);
            // 
            // lbRequerimiento
            // 
            this.lbRequerimiento.AutoSize = true;
            this.lbRequerimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRequerimiento.Location = new System.Drawing.Point(270, 9);
            this.lbRequerimiento.Name = "lbRequerimiento";
            this.lbRequerimiento.Size = new System.Drawing.Size(224, 20);
            this.lbRequerimiento.TabIndex = 6;
            this.lbRequerimiento.Text = "Registro de Requerimiento";
            // 
            // lbTipo_Requerimiento
            // 
            this.lbTipo_Requerimiento.AutoSize = true;
            this.lbTipo_Requerimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbTipo_Requerimiento.Location = new System.Drawing.Point(129, 48);
            this.lbTipo_Requerimiento.Name = "lbTipo_Requerimiento";
            this.lbTipo_Requerimiento.Size = new System.Drawing.Size(138, 15);
            this.lbTipo_Requerimiento.TabIndex = 7;
            this.lbTipo_Requerimiento.Text = "Tipo Requerimiento:";
            // 
            // lbAsignado
            // 
            this.lbAsignado.AutoSize = true;
            this.lbAsignado.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAsignado.Location = new System.Drawing.Point(129, 119);
            this.lbAsignado.Name = "lbAsignado";
            this.lbAsignado.Size = new System.Drawing.Size(82, 15);
            this.lbAsignado.TabIndex = 8;
            this.lbAsignado.Text = "Asignado a:";
            // 
            // lbOpcion
            // 
            this.lbOpcion.AutoSize = true;
            this.lbOpcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOpcion.Location = new System.Drawing.Point(270, 72);
            this.lbOpcion.Name = "lbOpcion";
            this.lbOpcion.Size = new System.Drawing.Size(248, 13);
            this.lbOpcion.TabIndex = 9;
            this.lbOpcion.Text = "(Base de Datos, Sistemas, Instalacion de Software)";
            // 
            // lbDescripcion
            // 
            this.lbDescripcion.AutoSize = true;
            this.lbDescripcion.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbDescripcion.Location = new System.Drawing.Point(129, 195);
            this.lbDescripcion.Name = "lbDescripcion";
            this.lbDescripcion.Size = new System.Drawing.Size(205, 15);
            this.lbDescripcion.TabIndex = 10;
            this.lbDescripcion.Text = "Descripcion del requerimiento:";
            // 
            // lbAsignacion
            // 
            this.lbAsignacion.AutoSize = true;
            this.lbAsignacion.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbAsignacion.Location = new System.Drawing.Point(270, 137);
            this.lbAsignacion.Name = "lbAsignacion";
            this.lbAsignacion.Size = new System.Drawing.Size(297, 13);
            this.lbAsignacion.TabIndex = 11;
            this.lbAsignacion.Text = "(Este usuario sera el responsable de resolver el requerimiento)";
            // 
            // txtdescripcion
            // 
            this.txtdescripcion.Location = new System.Drawing.Point(132, 223);
            this.txtdescripcion.Multiline = true;
            this.txtdescripcion.Name = "txtdescripcion";
            this.txtdescripcion.Size = new System.Drawing.Size(466, 91);
            this.txtdescripcion.TabIndex = 12;
            // 
            // lbPrioridad
            // 
            this.lbPrioridad.AutoSize = true;
            this.lbPrioridad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPrioridad.Location = new System.Drawing.Point(129, 353);
            this.lbPrioridad.Name = "lbPrioridad";
            this.lbPrioridad.Size = new System.Drawing.Size(70, 15);
            this.lbPrioridad.TabIndex = 13;
            this.lbPrioridad.Text = "Prioridad:";
            // 
            // lbOpPrioridad
            // 
            this.lbOpPrioridad.AutoSize = true;
            this.lbOpPrioridad.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbOpPrioridad.Location = new System.Drawing.Point(273, 375);
            this.lbOpPrioridad.Name = "lbOpPrioridad";
            this.lbOpPrioridad.Size = new System.Drawing.Size(93, 13);
            this.lbOpPrioridad.TabIndex = 14;
            this.lbOpPrioridad.Text = "(Alta, Media, Baja)";
            // 
            // frmIngresar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.ClientSize = new System.Drawing.Size(710, 511);
            this.Controls.Add(this.lbOpPrioridad);
            this.Controls.Add(this.lbPrioridad);
            this.Controls.Add(this.txtdescripcion);
            this.Controls.Add(this.lbAsignacion);
            this.Controls.Add(this.lbDescripcion);
            this.Controls.Add(this.lbOpcion);
            this.Controls.Add(this.lbAsignado);
            this.Controls.Add(this.lbTipo_Requerimiento);
            this.Controls.Add(this.lbRequerimiento);
            this.Controls.Add(this.btnLista_Req);
            this.Controls.Add(this.btnLimpiarCampo);
            this.Controls.Add(this.btnGuardar);
            this.Controls.Add(this.cmbPrioridad);
            this.Controls.Add(this.cmbAsignacion);
            this.Controls.Add(this.cmbTipo_Requerimiento);
            this.Name = "frmIngresar";
            this.Text = "Registro Requerimiento";
            this.Load += new System.EventHandler(this.frmIngresar_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbTipo_Requerimiento;
        private System.Windows.Forms.ComboBox cmbAsignacion;
        private System.Windows.Forms.ComboBox cmbPrioridad;
        private System.Windows.Forms.Button btnGuardar;
        private System.Windows.Forms.Button btnLista_Req;
        private System.Windows.Forms.Label lbRequerimiento;
        private System.Windows.Forms.Label lbTipo_Requerimiento;
        private System.Windows.Forms.Label lbAsignado;
        private System.Windows.Forms.Label lbOpcion;
        private System.Windows.Forms.Label lbDescripcion;
        private System.Windows.Forms.Label lbAsignacion;
        private System.Windows.Forms.TextBox txtdescripcion;
        private System.Windows.Forms.Label lbPrioridad;
        private System.Windows.Forms.Label lbOpPrioridad;
        private System.Windows.Forms.Button btnLimpiarCampo;
    }
}