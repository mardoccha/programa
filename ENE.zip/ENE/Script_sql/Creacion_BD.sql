--Creacion de la base de dato
CREATE DATABASE ENE_AIEP;
--Poner en uso la BD
USE ENE_AIEP;
