﻿
namespace sistema_req_part1
{
    partial class frmConsultar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.cmbRequerimiento = new System.Windows.Forms.ComboBox();
            this.cmbPrioridad = new System.Windows.Forms.ComboBox();
            this.lbRequerimiento = new System.Windows.Forms.Label();
            this.lbPrioridad = new System.Windows.Forms.Label();
            this.chkPendiente = new System.Windows.Forms.CheckBox();
            this.chkResuelto = new System.Windows.Forms.CheckBox();
            this.dgvRequerimiento = new System.Windows.Forms.DataGridView();
            this.btnResuelto = new System.Windows.Forms.Button();
            this.btnEliminar = new System.Windows.Forms.Button();
            this.btnBuscar = new System.Windows.Forms.Button();
            this.lbListaRequerimiento = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequerimiento)).BeginInit();
            this.SuspendLayout();
            // 
            // cmbRequerimiento
            // 
            this.cmbRequerimiento.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.cmbRequerimiento.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbRequerimiento.FormattingEnabled = true;
            this.cmbRequerimiento.Location = new System.Drawing.Point(258, 50);
            this.cmbRequerimiento.Name = "cmbRequerimiento";
            this.cmbRequerimiento.Size = new System.Drawing.Size(193, 21);
            this.cmbRequerimiento.TabIndex = 0;
            // 
            // cmbPrioridad
            // 
            this.cmbPrioridad.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.cmbPrioridad.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cmbPrioridad.FormattingEnabled = true;
            this.cmbPrioridad.Location = new System.Drawing.Point(258, 140);
            this.cmbPrioridad.Name = "cmbPrioridad";
            this.cmbPrioridad.Size = new System.Drawing.Size(193, 21);
            this.cmbPrioridad.TabIndex = 1;
            // 
            // lbRequerimiento
            // 
            this.lbRequerimiento.AutoSize = true;
            this.lbRequerimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbRequerimiento.Location = new System.Drawing.Point(81, 55);
            this.lbRequerimiento.Name = "lbRequerimiento";
            this.lbRequerimiento.Size = new System.Drawing.Size(149, 16);
            this.lbRequerimiento.TabIndex = 2;
            this.lbRequerimiento.Text = "Tipo Requerimiento:";
            // 
            // lbPrioridad
            // 
            this.lbPrioridad.AutoSize = true;
            this.lbPrioridad.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbPrioridad.Location = new System.Drawing.Point(81, 145);
            this.lbPrioridad.Name = "lbPrioridad";
            this.lbPrioridad.Size = new System.Drawing.Size(76, 16);
            this.lbPrioridad.TabIndex = 3;
            this.lbPrioridad.Text = "Prioridad:";
            // 
            // chkPendiente
            // 
            this.chkPendiente.AutoSize = true;
            this.chkPendiente.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkPendiente.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkPendiente.Location = new System.Drawing.Point(84, 208);
            this.chkPendiente.Name = "chkPendiente";
            this.chkPendiente.Size = new System.Drawing.Size(105, 20);
            this.chkPendiente.TabIndex = 4;
            this.chkPendiente.Text = "Pendientes";
            this.chkPendiente.UseVisualStyleBackColor = true;
            // 
            // chkResuelto
            // 
            this.chkResuelto.AutoSize = true;
            this.chkResuelto.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.chkResuelto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chkResuelto.Location = new System.Drawing.Point(304, 208);
            this.chkResuelto.Name = "chkResuelto";
            this.chkResuelto.Size = new System.Drawing.Size(97, 20);
            this.chkResuelto.TabIndex = 5;
            this.chkResuelto.Text = "Resueltos";
            this.chkResuelto.UseVisualStyleBackColor = true;
            // 
            // dgvRequerimiento
            // 
            this.dgvRequerimiento.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvRequerimiento.Location = new System.Drawing.Point(53, 252);
            this.dgvRequerimiento.Name = "dgvRequerimiento";
            this.dgvRequerimiento.Size = new System.Drawing.Size(699, 182);
            this.dgvRequerimiento.TabIndex = 6;
            // 
            // btnResuelto
            // 
            this.btnResuelto.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResuelto.Location = new System.Drawing.Point(123, 467);
            this.btnResuelto.Name = "btnResuelto";
            this.btnResuelto.Size = new System.Drawing.Size(189, 35);
            this.btnResuelto.TabIndex = 7;
            this.btnResuelto.Text = "Marcar como resuelto";
            this.btnResuelto.UseVisualStyleBackColor = true;
            this.btnResuelto.Click += new System.EventHandler(this.btnResuelto_Click);
            // 
            // btnEliminar
            // 
            this.btnEliminar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEliminar.Location = new System.Drawing.Point(359, 467);
            this.btnEliminar.Name = "btnEliminar";
            this.btnEliminar.Size = new System.Drawing.Size(125, 35);
            this.btnEliminar.TabIndex = 8;
            this.btnEliminar.Text = "Eliminar";
            this.btnEliminar.UseVisualStyleBackColor = true;
            this.btnEliminar.Click += new System.EventHandler(this.btnEliminar_Click);
            // 
            // btnBuscar
            // 
            this.btnBuscar.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnBuscar.Location = new System.Drawing.Point(485, 198);
            this.btnBuscar.Name = "btnBuscar";
            this.btnBuscar.Size = new System.Drawing.Size(108, 38);
            this.btnBuscar.TabIndex = 9;
            this.btnBuscar.Text = "Buscar";
            this.btnBuscar.UseVisualStyleBackColor = true;
            this.btnBuscar.Click += new System.EventHandler(this.btnBuscar_Click);
            // 
            // lbListaRequerimiento
            // 
            this.lbListaRequerimiento.AutoSize = true;
            this.lbListaRequerimiento.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbListaRequerimiento.Location = new System.Drawing.Point(241, 9);
            this.lbListaRequerimiento.Name = "lbListaRequerimiento";
            this.lbListaRequerimiento.Size = new System.Drawing.Size(243, 20);
            this.lbListaRequerimiento.TabIndex = 10;
            this.lbListaRequerimiento.Text = "LISTA DE REQUERIMIENTO";
            // 
            // frmConsultar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.ClientSize = new System.Drawing.Size(800, 514);
            this.Controls.Add(this.lbListaRequerimiento);
            this.Controls.Add(this.btnBuscar);
            this.Controls.Add(this.btnEliminar);
            this.Controls.Add(this.btnResuelto);
            this.Controls.Add(this.dgvRequerimiento);
            this.Controls.Add(this.chkResuelto);
            this.Controls.Add(this.chkPendiente);
            this.Controls.Add(this.lbPrioridad);
            this.Controls.Add(this.lbRequerimiento);
            this.Controls.Add(this.cmbPrioridad);
            this.Controls.Add(this.cmbRequerimiento);
            this.Name = "frmConsultar";
            this.Text = "Consultar Requerimientos";
            this.Load += new System.EventHandler(this.frmConsultar_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvRequerimiento)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox cmbRequerimiento;
        private System.Windows.Forms.ComboBox cmbPrioridad;
        private System.Windows.Forms.Label lbRequerimiento;
        private System.Windows.Forms.Label lbPrioridad;
        private System.Windows.Forms.CheckBox chkPendiente;
        private System.Windows.Forms.CheckBox chkResuelto;
        private System.Windows.Forms.DataGridView dgvRequerimiento;
        private System.Windows.Forms.Button btnResuelto;
        private System.Windows.Forms.Button btnEliminar;
        private System.Windows.Forms.Button btnBuscar;
        private System.Windows.Forms.Label lbListaRequerimiento;
    }
}