--Creacion de la tabla usuario
CREATE TABLE  USUARIO( Id_User VARCHAR(30) NOT NULL,
                     Clave VARCHAR(20) NOT NULL,
					 Pri_Nombre  VARCHAR(30) NOT NULL,
				     Seg_Nombre  VARCHAR(30),
					 Ape_Paterno VARCHAR(30) NOT NULL,
					 Ape_Materno VARCHAR(30),
					 Cod_rol INT NOT NULL,
					 CONSTRAINT pk_usuario PRIMARY KEY(Id_User),
					 CONSTRAINT fk_usuario_rol FOREIGN KEY (Cod_rol)
                     REFERENCES ROL(Cod_rol)
					 );

SElECT * FROM USUARIO;

INSERT INTO USUARIO(Id_User, Clave, Pri_Nombre, Seg_Nombre, Ape_Paterno, Ape_Materno, Cod_rol)

VALUES ('Mardoccha', '15121989', 'Mardoche', '', 'Charitable','', 1),
       ('Kro.damian', '123456','Carolina', 'Paz','Vergara','Jorquera',2);