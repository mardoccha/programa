CREATE TABLE REQUERIMIENTO( Cod_req INT IDENTITY(1,1) NOT NULL,
                       Estado BIT, -- 1: pendiente, 0: resuelto
					   Descripcion VARCHAR(200) NOT NULL,
					   Fecha Date,
					   Cod_tipo INT,
					   Cod_prioridad INT,
					   Id_user VARCHAR(30) NOT NULL,
                     CONSTRAINT pk_requerimineto PRIMARY KEY(Cod_req),
					 CONSTRAINT fk_req_usuario FOREIGN KEY (Id_user)
                     REFERENCES USUARIO(Id_user),
					 CONSTRAINT fk_req_tipo_req FOREIGN KEY (Cod_tipo)
                     REFERENCES TIPO_REQUERIMIENTO(Cod_tipo),
					 CONSTRAINT fk_req_prioridad FOREIGN KEY (Cod_prioridad)
                     REFERENCES PRIORIDAD(Cod_prioridad)
					 );

SELECT * FROM REQUERIMIENTO;

INSERT INTO REQUERIMIENTO(Estado,Descripcion, Fecha, Cod_tipo, Cod_prioridad, Id_user) 
VALUES (0, 'Instalar office', GETDATE(), 3,6,'Mardoccha');
       (1, 'Instalar anti-virus', GETDATE(), 5,2,'Kro.damian'),
       (1, 'crear store procedure', GETDATE(), 1,6,'Mardoccha'),
       (1, 'update sistema', GETDATE(), 3,2,'Kro.damian');

	   ALTER TABLE REQUERIMIENTO ALTER COLUMN Estado CHAR(1);
	   UPDATE REQUERIMIENTO
SET Estado='P' WHERE Cod_req=2
UPDATE REQUERIMIENTO
SET Estado='P' WHERE Cod_req=3
UPDATE REQUERIMIENTO
SET Estado='P' WHERE Cod_req=4
UPDATE REQUERIMIENTO
SET Estado='R' WHERE Cod_req=5
UPDATE REQUERIMIENTO
SET Estado='R' WHERE Cod_req=6
UPDATE REQUERIMIENTO
SET Estado='R' WHERE Cod_req=7