USE ENE_AIEP;
--CREACION TABLA ROL
CREATE TABLE  ROL( Cod_rol INT IDENTITY (1, 1) CONSTRAINT pk_Rol PRIMARY KEY,
                     Nombre VARCHAR(100) NOT NULL,
				
				 );


INSERT INTO ROL(Nombre)

VALUES  ('Administrador del sistema'),
        ('Analista de requerimiento');

SELECT * FROM ROL;