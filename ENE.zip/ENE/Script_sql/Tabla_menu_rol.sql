CREATE TABLE MENU_ROL( Cod_menu VARCHAR(10) NOT NULL,
                       Cod_rol INT NOT NULL,
					 
                     CONSTRAINT pk_Menu_rol PRIMARY KEY(Cod_menu, Cod_rol),
					 CONSTRAINT fk_rol_menu FOREIGN KEY (Cod_rol)
                     REFERENCES ROL(Cod_rol),
					 CONSTRAINT fk_Menu_rol_menu FOREIGN KEY (Cod_menu)
                     REFERENCES MENU(Cod_menu)
					 );


SELECT *FROM MENU_ROL;

INSERT INTO MENU_ROL(Cod_menu, Cod_rol) 
VALUES ('SRO1', 1),
       ('SRO1', 2),
       ('SRO2', 2);
	   