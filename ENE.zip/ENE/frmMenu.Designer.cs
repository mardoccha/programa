﻿
namespace sistema_req_part1
{
    partial class frmMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.requerimientoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ingresarRequerimientoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.consultarRequerimientoToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.acercaDeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.requerimientoToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(800, 24);
            this.menuStrip1.TabIndex = 1;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // requerimientoToolStripMenuItem
            // 
            this.requerimientoToolStripMenuItem.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.requerimientoToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.ingresarRequerimientoToolStripMenuItem,
            this.consultarRequerimientoToolStripMenuItem});
            this.requerimientoToolStripMenuItem.Name = "requerimientoToolStripMenuItem";
            this.requerimientoToolStripMenuItem.Size = new System.Drawing.Size(97, 20);
            this.requerimientoToolStripMenuItem.Text = "Requerimiento";
            // 
            // ingresarRequerimientoToolStripMenuItem
            // 
            this.ingresarRequerimientoToolStripMenuItem.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ingresarRequerimientoToolStripMenuItem.Name = "ingresarRequerimientoToolStripMenuItem";
            this.ingresarRequerimientoToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.ingresarRequerimientoToolStripMenuItem.Text = "Ingresar Requerimiento";
            this.ingresarRequerimientoToolStripMenuItem.Click += new System.EventHandler(this.ingresarRequerimientoToolStripMenuItem_Click);
            // 
            // consultarRequerimientoToolStripMenuItem
            // 
            this.consultarRequerimientoToolStripMenuItem.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.consultarRequerimientoToolStripMenuItem.Name = "consultarRequerimientoToolStripMenuItem";
            this.consultarRequerimientoToolStripMenuItem.Size = new System.Drawing.Size(206, 22);
            this.consultarRequerimientoToolStripMenuItem.Text = "Consultar Requerimiento";
            this.consultarRequerimientoToolStripMenuItem.Click += new System.EventHandler(this.consultarRequerimientoToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.acercaDeToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // acercaDeToolStripMenuItem
            // 
            this.acercaDeToolStripMenuItem.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.acercaDeToolStripMenuItem.Name = "acercaDeToolStripMenuItem";
            this.acercaDeToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.acercaDeToolStripMenuItem.Text = "Acerca de";
            this.acercaDeToolStripMenuItem.Click += new System.EventHandler(this.acercaDeToolStripMenuItem_Click);
            // 
            // frmMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.menuStrip1);
            this.IsMdiContainer = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "frmMenu";
            this.Text = "Sistema de Control de Requerimiento";
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem requerimientoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ingresarRequerimientoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem consultarRequerimientoToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem acercaDeToolStripMenuItem;
    }
}