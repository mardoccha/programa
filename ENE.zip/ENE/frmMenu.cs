﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistema_req_part1
{
    public partial class frmMenu : Form
    {
        public frmMenu()
        {
            InitializeComponent();
        }

        private void consultarRequerimientoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmConsultar fConsulta= new frmConsultar();
            fConsulta.MdiParent = this;
            fConsulta.Show();


        }

        private void ingresarRequerimientoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            frmIngresar fIngresar = new frmIngresar();
            fIngresar.MdiParent = this;
            fIngresar.Show();
        }

        private void acercaDeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Contacta al administrador: Mardoche Charitable, tel: 936654478, mail: mardoccha@gmail.com");
        }
    }
}
