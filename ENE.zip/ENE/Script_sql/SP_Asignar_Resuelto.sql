-- =============================================
-- Author:		MC
-- Create date: 15-12-2020
-- Description:	AsignarResuelto a un requerimiento
-- ======================================
CREATE PROCEDURE SP_Asignar_Resuelto(@Cod_req int)
as begin

  if exists ( select *  from REQUERIMIENTO where Cod_req = @Cod_req)
	begin 
	  update REQUERIMIENTO
	  set Estado = 'R'
	  where Cod_req = @Cod_req

	  select 0 as Codigo_Ret,'Requerimiento Resuelto.' as Mensaje_Ret 
	end
   else
	  select 1 as Codigo_Ret,'Numero de requerimiento no existe.' as Mensaje_Ret 
end
