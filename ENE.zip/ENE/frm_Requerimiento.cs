﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace sistema_req_part1
{
    public partial class frm_Requerimiento : Form
    {
        public frm_Requerimiento()
        {
            InitializeComponent();
        }

        private void btnIngresar_Click(object sender, EventArgs e)
        {
            string Usuario, Clave;

            if (txtUsuario.TextLength == 0)
            {
                MessageBox.Show("Debe ingresar el usuario");
                return;
            }
            if (txtClave.TextLength == 0)
            {
                MessageBox.Show("Debe ingresar la clave");
                return;
            }
            Usuario = txtUsuario.Text;
            Clave = txtClave.Text;
            //  conexion a la database
            string cadenaConexion = "Server = DESKTOP-Q3S0R8O\\SQLEXPRESS ; Database = ENE_AIEP;  integrated security = true";
            SqlConnection sqlCon = new SqlConnection(cadenaConexion);
            sqlCon.Open();

            // ejecutar Store procedure de la db
            SqlCommand sqlCmd;


            sqlCmd = new SqlCommand("sp_VALIDAR_USUARIO", sqlCon);
            sqlCmd.CommandType = CommandType.StoredProcedure;
            sqlCmd.Parameters.AddWithValue("@Id_User", Usuario);
            sqlCmd.Parameters.AddWithValue("@Clave", Clave);

            SqlDataAdapter sqlSda = new SqlDataAdapter(sqlCmd);
            DataTable dtData = new DataTable();
            sqlSda.Fill(dtData);


            if (dtData.Rows.Count > 0)
            {
                if (Convert.ToInt32(dtData.Rows[0]["Codigo_Ret"]) != 0)
                {
                    MessageBox.Show("No puede acceder al sistema");
                }
                else
                {
                    // desplegar la pantalla de Ingreso de Requerimientos
                    this.Hide(); // ocultar pantall de login
                    frmMenu fMenu = new frmMenu();
                    fMenu.ShowDialog();

                    sqlCon.Close();
                }
            }
        }
        private void chkbVer_CheckedChanged(object sender, EventArgs e)
        {
            if(chkbVer.Checked==true)
            {
                txtClave.UseSystemPasswordChar = false;
            }
            else
            {
                txtClave.UseSystemPasswordChar = true;

            }
        }
    }
}


        
    

