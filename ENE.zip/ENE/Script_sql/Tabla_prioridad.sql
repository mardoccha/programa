CREATE TABLE PRIORIDAD( Cod_prioridad INT IDENTITY (2, 2) NOT NULL,
                     Nivel VARCHAR(10) NOT NULL,
					 Plazo VARCHAR(10) NOT NULL,
					 
                     CONSTRAINT pk_prioridad PRIMARY KEY(Cod_prioridad),
					);

SELECT * FROM PRIORIDAD;

INSERT INTO PRIORIDAD(Nivel, Plazo)

VALUES ('Alta','3 dias'),
       ('Media','4 dias'),
	   ('Baja','5 dias');