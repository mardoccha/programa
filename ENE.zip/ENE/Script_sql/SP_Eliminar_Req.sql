-- =============================================
-- Author:		MC
-- Create date: 15-12-2020
-- Description:	Eliminar un requerimiento
-- ======================================
CREATE PROCEDURE SP_Eliminar_Req(@Cod_req int)
as begin
  delete from REQUERIMIENTO where Cod_req = @Cod_req
  select 0 as Codigo_Ret,'Requerimiento ' + convert(varchar(10),@Cod_req ) +' fue eliminado' as Mensaje_Ret
end