CREATE TABLE TIPO_REQUERIMIENTO( Cod_tipo INT IDENTITY (1, 2) NOT NULL,
                     Tipo VARCHAR(50) NOT NULL,
					 CONSTRAINT pk_T_Requerimiento PRIMARY KEY(Cod_tipo)
					);

SELECT *FROM TIPO_REQUERIMIENTO;

INSERT INTO TIPO_REQUERIMIENTO(Tipo)

VALUES ('Base de Datos'),
       ('Sistema'),
	   ('Instalacion de software');