-- =============================================
-- Author:		MC
-- Create date: 17-12-2020
-- Description:	cONSULTAR_Requerimiento
--permita validar el estado de un requerimiento con su tipo y prioridad
--y retornar una tabla con los datos.
-- =============================================
CREATE PROCEDURE sp_cONSULTAR_Requerimiento
	-- aqui los parametros de entradas y de salidas
		@Cod_tipo int, 
		@Cod_prioridad int, 
		@Estado CHAR(1)
as
begin
	select	R.Cod_req AS 'C�digo',
	CASE R.Estado
            WHEN 'P' THEN 'Pendiente'
            WHEN 'R' THEN 'Resuelto'
            ELSE 'No lo indica' -- valor por defecto
            END  AS 'Estado',
			R.Descripcion AS 'Descripci�n',
			TR.Tipo AS 'Tipo Requerimiento',
			P.Nivel AS 'Prioridad',
			P.plazo AS 'Plazo'

	from requerimiento AS R

	inner join Prioridad AS P
	on R.Cod_prioridad = P.Cod_prioridad

	inner join TIPO_REQUERIMIENTO TR
	on TR.Cod_Tipo = R.Cod_Tipo

	where ( R.Cod_Tipo = @Cod_tipo or @Cod_tipo =0) 
	and   ( R.Cod_prioridad = @Cod_prioridad or @Cod_prioridad = 0)
	and   ( R.Estado = @estado or @estado ='T') 
end


